package aaa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class MemberDBBean {
	
	private static MemberDBBean instance = new MemberDBBean();
	public static MemberDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public String findId(String MEM_NAME, String MEM_EMAIL) {
		String sql = "select MEM_ID from MEMBER where MEM_NAME=? AND MEM_EMAIL=?";
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String mid = null;
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, MEM_NAME);
			ps.setString(2, MEM_EMAIL);
			
			rs = ps.executeQuery();
			
			if (rs.next()) {
				mid = rs.getString("MEM_ID");
			}

			rs.close();
			ps.close();
			conn.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return mid;
	}
	
	public String findPw(String MEM_ID, String MEM_EMAIL) {
		String pw = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select MEM_PW from MEMBER where MEM_ID=? AND MEM_EMAIL=?";
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, MEM_ID);
			ps.setString(2, MEM_EMAIL);
			
			rs = ps.executeQuery();
			
			if (rs.next()) {
				pw = rs.getString("MEM_PW");
			}
			
			rs.close();
			ps.close();
			conn.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return pw;
	}
	
	public ArrayList<BoardBean> getMyWrite(String MEM_PW, String MEM_NO) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = "select BO_TITLE, BO_CONTENT, BO_DATE FROM BOARD WHERE MEMBER_MEM_ID = (SELECT MEM_ID FROM MEMBER WHERE MEM_PW=? and MEM_NO=?)";
		ArrayList<BoardBean> content = new ArrayList<BoardBean>();
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, MEM_PW);
			ps.setString(2, MEM_NO);
			
			
			rs = ps.executeQuery();
			
		while (rs.next()) {
			BoardBean item = new BoardBean();
			
			item.setBO_TITLE(rs.getString(1));
			item.setBO_CONTENT(rs.getString(2));
			item.setBO_DATE(rs.getDate(3));
			
			content.add(item);
		}

			rs.close();
			ps.close();
			conn.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		return content;
	}
	
	public int insertMember(MemberBean member) {
		Connection conn = null;
		PreparedStatement ps = null;
		int re = -1;
		
		String sql = "insert into member (MEM_ID, MEM_PW, MEM_NAME, MEM_EMAIL, MEM_TYPE, MEM_TEL, MEM_BIRTH, MEM_CONTENT, MEM_CLASS, MEM_LICENSE, MEM_IMAGE, CLASS_CLA_NO) values (?,?,?,?,?,?,?,?,?,?,?,?)";
		String sql2="(SELECT CLA_NO FROM CLASS WHERE CLA_NAME='DEFAULT')" ;
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, member.getMEM_ID());
			ps.setString(2, member.getMEM_PW());
			ps.setString(3, member.getMEM_NAME());
			ps.setString(4, member.getMEM_EMAIL());
			ps.setInt(5, 3);
			ps.setString(6, member.getMEM_TEL());
			ps.setString(7, member.getMEM_BIRTH());
			ps.setString(8, "반갑습니다"+member.getMEM_NAME()+"입니다");
			ps.setInt(9, 0);
			ps.setString(10, "없음");
			ps.setString(11, "default_profile.png");
			ps.setInt(12, 0);
			
			re = ps.executeUpdate();
			

			ps.close();
			conn.close();
			
			System.out.println("입력성공");
		}catch (Exception e) {
			System.out.println("입력실패");
			e.printStackTrace();
		}
		return re;
	}
	
//	public String getDefProfile() {
		
//	}
}
