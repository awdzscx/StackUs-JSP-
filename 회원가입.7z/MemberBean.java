package aaa;


public class MemberBean {
	private String MEM_ID;
	private String MEM_PW; 
	private String MEM_EMAIL; 
	private String MEM_BIRTH;   	
	private String MEM_CONTENT;
	private int MEM_TYPE;
	private int MEM_CLASS;
	private String MEM_TEL;	
	private String MEM_LICENSE;
	private String MEM_NAME;
	
	
	
	public String getMEM_ID() {
		return MEM_ID;
	}
	public void setMEM_ID(String mEM_ID) {
		MEM_ID = mEM_ID;
	}
	public String getMEM_PW() {
		return MEM_PW;
	}
	public void setMEM_PW(String mEM_PW) {
		MEM_PW = mEM_PW;
	}
	public String getMEM_EMAIL() {
		return MEM_EMAIL;
	}
	public void setMEM_EMAIL(String mEM_EMAIL) {
		MEM_EMAIL = mEM_EMAIL;
	}
	public String getMEM_BIRTH() {
		return MEM_BIRTH;
	}
	public void setMEM_BIRTH(String mEM_BIRTH) {
		MEM_BIRTH = mEM_BIRTH;
	}
	public String getMEM_CONTENT() {
		return MEM_CONTENT;
	}
	public void setMEM_CONTENT(String mEM_CONTENT) {
		MEM_CONTENT = mEM_CONTENT;
	}
	public int getMEM_TYPE() {
		return MEM_TYPE;
	}
	public void setMEM_TYPE(int mEM_TYPE) {
		MEM_TYPE = mEM_TYPE;
	}
	public int getMEM_CLASS() {
		return MEM_CLASS;
	}
	public void setMEM_CLASS(int mEM_CLASS) {
		MEM_CLASS = mEM_CLASS;
	}
	
	public String getMEM_TEL() {
		return MEM_TEL;
	}
	public void setMEM_TEL(String mEM_TEL) {
		MEM_TEL = mEM_TEL;
	}
	public String getMEM_LICENSE() {
		return MEM_LICENSE;
	}
	public void setMEM_LICENSE(String mEM_LICENSE) {
		MEM_LICENSE = mEM_LICENSE;
	}
	public String getMEM_NAME() {
		return MEM_NAME;
	}
	public void setMEM_NAME(String mEM_NAME) {
		MEM_NAME = mEM_NAME;
	}
	
	
	
		
}
