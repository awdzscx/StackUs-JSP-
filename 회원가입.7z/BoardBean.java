package aaa;

import java.util.Date;

public class BoardBean {
	private String BO_TITLE;
	private String BO_CONTENT;
	private Date BO_DATE;
	private int BO_NO;
	private int BO_HIT;
	public String getBO_TITLE() {
		return BO_TITLE;
	}
	public void setBO_TITLE(String bO_TITLE) {
		BO_TITLE = bO_TITLE;
	}
	public String getBO_CONTENT() {
		return BO_CONTENT;
	}
	public void setBO_CONTENT(String bO_CONTENT) {
		BO_CONTENT = bO_CONTENT;
	}
	public Date getBO_DATE() {
		return BO_DATE;
	}
	public void setBO_DATE(Date bO_DATE) {
		BO_DATE = bO_DATE;
	}
	public int getBO_NO() {
		return BO_NO;
	}
	public void setBO_NO(int bO_NO) {
		BO_NO = bO_NO;
	}
	public int getBO_HIT() {
		return BO_HIT;
	}
	public void setBO_HIT(int bO_HIT) {
		BO_HIT = bO_HIT;
	}
	
	
}
