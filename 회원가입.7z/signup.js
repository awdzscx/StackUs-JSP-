function signUpCheck(){
		var frm = document.resfrm;
		
		if(frm.MEM_EMAIL.value.length < 1){
			alert("EMAIL을 입력해주세요");
			return;
		}
		
		if(frm.MEM_ID.value.length < 1){
			alert("ID를 입력해주세요");
			return;
		}

		if(frm.MEM_NAME.value.length < 1){
			alert("이름을 입력해주세요");
			return;
		}
	

		if(frm.MEM_BIRTH.value.length < 10){
			alert("생일을 입력해주세요");
			return;
		}
		
		if(frm.MEM_PW.value.length < 1){
			alert("비밀번호를 입력해주세요");
			return;
		}
	
		if(frm.MEM_PW.value != frm.pwcheck.value){
			alert("비밀번호가 틀립니다");
			return;
		}
		
		if(frm.phone2.value.length < 4){
			alert("전화번호를 입력해주세요");
			return;
		}

		if(frm.phone3.value.length < 4){
			alert("전화번호를 입력해주세요");
			return;
		}
		
		/*frm.method = "post";
		frm.action = "resiOK.jsp"; //넘어간 화면*/
		frm.submit();
}

function tsignUpCheck(){
		var frm = document.tresfrm;
		
		if(frm.TEA_EMAIL.value.length < 1){
			alert("EMAIL을 입력해주세요");
			return;
		}
		
		if(frm.TEA_ID.value.length < 1){
			alert("아이디를 입력해주세요");
			return;
		}
		
		if(frm.TEA_NAME.value.length < 1){
			alert("이름을 입력해주세요");
			return;
		}

		if(frm.TEA_BIRTH.value.length < 10){
			alert("생일을 입력해주세요");
			return;
		}

		if(frm.TEA_PW.value.length < 1){
			alert("비밀번호를 입력해주세요");
			return;
		}

		if(frm.TEA_PW.value != frm.tpwcheck.value){
			alert("비밀번호를 입력해주세요");
			return;
		}
		
		if(frm.TEA_PW.value == null){
			alert("전공을 입력해주세요");
			return;
		}

		if(frm.tphone2.value.length < 4){
			alert("전화번호를 입력해주세요");
			return;
		}

		if(frm.tphone3.value.length < 4){
			alert("전화번호를 입력해주세요");
			return;
		}

		/*frm.method = "post";
		frm.action = "tresiOK.jsp"; //넘어간 화면*/
		frm.submit();
}