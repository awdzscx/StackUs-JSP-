package aaa;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class TeacherDBBean {
 
	private static TeacherDBBean instance = new TeacherDBBean();
	public static TeacherDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public int insertTeacher(TeacherBean teacher) {
		Connection conn = null;
		PreparedStatement ps = null;
		int re = -1;
		
		String sql = "insert into teacher (TEA_ID,TEA_PW,TEA_EMAIL,TEA_NAME,TEA_BIRTH) values (?,?,?,?,?)";
//		String sql = "insert into test1 values (?,?,?,?,?,?)";
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, teacher.getTEA_ID());
			ps.setString(2, teacher.getTEA_PW());
			ps.setString(3, teacher.getTEA_EMAIL());
			ps.setString(4, teacher.getTEA_NAME());
			ps.setString(5, teacher.getTEA_BIRTH());
			ps.setString(6, teacher.getTEA_MAJOR());
			
			re = ps.executeUpdate();
			
			ps.close();
			conn.close();
			
			System.out.println("입력성공");
			
		} catch (Exception e) {
			System.out.println("입력실패");
			e.printStackTrace();
		}
		return re;
	}
}
