package aaa;

import java.util.Date;

public class TeacherBean {
	private int TYPE;
	private int TEA_NO;
	private String TEA_ID;
	private String TEA_PW;
	private int TEA_CLASS;
	private String TEA_MAJOR;
	private String TEA_NAME;
	private String TEA_BIRTH;
	private String TEA_EMAIL;
	private String TEA_TEL;
	
	
	public int getTYPE() {
		return TYPE;
	}
	public void setTYPE(int tYPE) {
		TYPE = tYPE;
	}
	public int getTEA_NO() {
		return TEA_NO;
	}
	public void setTEA_NO(int tEA_NO) {
		TEA_NO = tEA_NO;
	}
	public String getTEA_ID() {
		return TEA_ID;
	}
	public void setTEA_ID(String tEA_ID) {
		TEA_ID = tEA_ID;
	}
	public String getTEA_PW() {
		return TEA_PW;
	}
	public void setTEA_PW(String tEA_PW) {
		TEA_PW = tEA_PW;
	}
	public int getTEA_CLASS() {
		return TEA_CLASS;
	}
	public void setTEA_CLASS(int tEA_CLASS) {
		TEA_CLASS = tEA_CLASS;
	}
	public String getTEA_MAJOR() {
		return TEA_MAJOR;
	}
	public void setTEA_MAJOR(String tEA_MAJOR) {
		TEA_MAJOR = tEA_MAJOR;
	}
	public String getTEA_NAME() {
		return TEA_NAME;
	}
	public void setTEA_NAME(String tEA_NAME) {
		TEA_NAME = tEA_NAME;
	}
	public String getTEA_BIRTH() {
		return TEA_BIRTH;
	}
	public void setTEA_BIRTH(String tEA_BIRTH) {
		TEA_BIRTH = tEA_BIRTH;
	}
	public String getTEA_EMAIL() {
		return TEA_EMAIL;
	}
	public void setTEA_EMAIL(String tEA_EMAIL) {
		TEA_EMAIL = tEA_EMAIL;
	}
	public String getTEA_TEL() {
		return TEA_TEL;
	}
	public void setTEA_TEL(String tEA_TEL) {
		TEA_TEL = tEA_TEL;
	}
	
	
}
